# Summary

Date : 2023-04-09 13:10:27

Directory c:\\Users\\amand\\Code\\source\\repos\\leaderboard\\frontend\\src

Total : 90 files,  19606 codes, 1194 comments, 1468 blanks, all 22268 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript JSX | 58 | 13,259 | 1,163 | 1,365 | 15,787 |
| XML | 8 | 5,644 | 0 | 8 | 5,652 |
| JavaScript | 19 | 596 | 31 | 83 | 710 |
| JSON | 4 | 76 | 0 | 4 | 80 |
| CSS | 1 | 31 | 0 | 8 | 39 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 90 | 19,606 | 1,194 | 1,468 | 22,268 |
| . (Files) | 4 | 158 | 14 | 19 | 191 |
| __tests__ | 8 | 113 | 0 | 24 | 137 |
| assets | 12 | 5,720 | 0 | 12 | 5,732 |
| assets\\Leaderboard_Logos | 12 | 5,720 | 0 | 12 | 5,732 |
| assets\\Leaderboard_Logos\\logo_black_favicon_package | 3 | 99 | 0 | 3 | 102 |
| assets\\Leaderboard_Logos\\logo_black_purple_favicon_package | 3 | 97 | 0 | 3 | 100 |
| assets\\Leaderboard_Logos\\logo_white_favicon_package | 3 | 123 | 0 | 3 | 126 |
| assets\\Leaderboard_Logos\\logo_white_purple_favicon_package | 3 | 5,401 | 0 | 3 | 5,404 |
| components | 39 | 8,705 | 599 | 871 | 10,175 |
| components (Files) | 37 | 7,920 | 543 | 782 | 9,245 |
| components\\lists | 2 | 785 | 56 | 89 | 930 |
| context | 1 | 27 | 0 | 9 | 36 |
| helperFunctions | 7 | 329 | 17 | 39 | 385 |
| pages | 19 | 4,554 | 564 | 494 | 5,612 |
| pages (Files) | 15 | 3,407 | 510 | 345 | 4,262 |
| pages\\lists | 4 | 1,147 | 54 | 149 | 1,350 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)